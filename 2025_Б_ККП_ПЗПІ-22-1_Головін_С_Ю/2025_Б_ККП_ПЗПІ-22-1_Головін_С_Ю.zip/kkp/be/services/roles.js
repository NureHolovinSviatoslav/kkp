const roles = {
  ADMIN: 'admin',
  STAFF: 'staff',
  IOT: 'iot',
};

module.exports = {
  roles,
};
