export type Login = {
  username: string;
  password: string;
};
