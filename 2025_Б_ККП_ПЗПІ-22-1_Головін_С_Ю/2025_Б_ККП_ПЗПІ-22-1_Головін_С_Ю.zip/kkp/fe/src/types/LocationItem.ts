export type LocationItem = {
  location_item_id: string;
  location_id: string;
  vaccine_id: string;
  quantity: number;
};
