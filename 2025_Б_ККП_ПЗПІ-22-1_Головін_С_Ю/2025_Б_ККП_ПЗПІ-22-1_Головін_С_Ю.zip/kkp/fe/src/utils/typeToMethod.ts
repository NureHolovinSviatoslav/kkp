export const typeToMethod = {
  create: "POST",
  update: "PATCH",
  delete: "DELETE",
};
